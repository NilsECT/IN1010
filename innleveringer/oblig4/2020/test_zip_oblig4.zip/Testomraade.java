import java.util.Scanner;

public class Testomraade {
    public static void main(String[] args){
        Scanner test = new Scanner(System.in);

        int nummer = test.nextInt();
    }
}
