public interface Godkjenningsfritak {
    int hentKontrollID();
}
